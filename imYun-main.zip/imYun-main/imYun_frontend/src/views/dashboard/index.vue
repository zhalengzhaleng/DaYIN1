<template>
  <div class="dashboard-container">
    <h1>传统打印店流程:客户到店U盘发送文件(微信、QQ传送)---店主打开(接收)---打印</h1>
    <h1>imYun打印流程:客户到店扫描小程序上传文件---店主通过后台管理端查看&打印</h1>
   <h1>github地址:</h1>
  </div>
</template>

<script>
export default {
  name: '',
  components: {
    
  },
  data() {
    return {

    }
  },
  methods: {

  }
}
</script>

const ossUrl = 'http://127.0.0.1:5000/v1/webs/order/getLocalFile/'
const downUrl = 'http://127.0.0.1:5000/v1/webs/order/getLocalFile/'
const wsURL = 'ws://127.0.0.1:5000/v1/webs/websocket'
export default {
    ossUrl,
    downUrl,
    wsURL
}